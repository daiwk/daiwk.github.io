ps aux | grep '/usr/bin/docker' | awk '{print $2}' | xargs kill -9

nohup /usr/bin/docker -d -b docker0 -H tcp://0.0.0.0:2375 -H unix:///var/run/docker.sock -s overlay --insecure-registry registry.baidu.com  --insecure-registry gpu.baidu.com:5000 -g /home/work/docker &
