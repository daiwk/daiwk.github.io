#!/bin/bash
set -e
echo "Upgrade Kernel Started"
mkdir -p /home/work/docker
mkdir -p /home/work/tmp
cd /home/work/tmp
uname -r
#���ع�˾3.10kernel
wget http://ikernel.baidu.com/3.10.0/kernel-3.10.0_2-0-0-1.tgz
tar zxf kernel-3.10.0_2-0-0-1.tgz
cd /home/work/tmp/kernel-3.10.0_2-0-0-1
set +e
./auto_changekernel.sh
set -e
#����cgroup fs
cd /home/work/tmp
wget http://10.107.26.32:8000/cgroupfs-mount
chmod +x cgroupfs-mount
./cgroupfs-mount
echo "Upgrade Kernel Finished"
shutdown -r now
