export PATH=/Library/TeX/texbin/:$PATH
